<?php

echo"Open source OpenInviter<sup>TM</sup> (Open Inviter<sup>TM</sup>) is a free import contacts (addressbook) script from email providers like Apropo, Gawab, IndiaTimes, Bordermail, Yandex, Mail.ru, Mynet.com, FastMail, Freemail, Sapo.pt, Techemail, AOL, KataMail, Inbox.com, Nz11, Virgilio, Abv, Canoe, India, Xing, Kids, Pochta, Aussiemail, Grafitti, Azet, Rambler, Web.de, Mail.com, Mail.in, Hushmail, Yahoo!, GMX.net, Live/Hotmail, Inet, OperaMail, 5Fm, Interia, Libero, Rediff, Mail2World, Clevergo, Wp.pt, Walla, O2, Terra, Uk2, Lycos, Meta, MSN, Atlas, YouTube, Zapakmail, LinkedIn, Plaxo, Bigstring, Care2, Netaddress, GMail, Evite, Popstarmail, Doramail or social portals like Twitter, MySpace, Eons, Orkut, Famiva, Mydogspace, Bebo, Last.fm, Vimeo, NetLog, Bookcrossing, Skyrock, Ning, Faces, Vkontakte, Koolro, Friendfeed, Hi5, Facebook, Konnects, Kincafe, Friendster, Livejournal, Fdcareer, Perfspot, Flickr, Flixster, Lovento, Flingr, Brazencareerist, Mevio, Cyworld, Plurk, Meinvz, Mycatspace, Plazes, Xuqa, Motortopia, Badoo, Multiply, Tagged, Xanga, Hyves. This contacts importer script is integrating with content management systems (aka CMS) like Social Engine, Social Engine 4, Drupal, Dating Pro, joovili, symfony, Atmail5, phpFoX, PunBB, myBB, jamit job, Vwebmail, Etano, PHPMELODY, E107, JamRoom, PhpBB, nowFire, SimpleMachines Forum (SMF), Joomla, phpizabi, Boonex Dolphin, vBulletin, Buddy Zone, RoundCube, Joomla1.0, Wordpress. Open Inviter is written in PHP 5 (no database required but cURL or wget required) and running on any webserver (tested on Apache) offering advanced tell a friend features. OpenInviter<sup>TM</sup> is a free self hosted solution that does not use a third party gateway (or API) to import contacts.Download it at: <a href='http://openinviter.com'>OpenInviter</a>";
?>
<?php

// On charge la config et les librairies
include('../config/config.php');

// create a new TwitterAvatars object
$ta = new TwitterApp(new tmhOAuth($config));

// check our authentication status
if($ta->isAuthed()) {
$success = true;
}
// did the user request authorization?
elseif(isset($_POST['auth'])) {

// start authentication process
$ta->auth();
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Connection</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<h1>Connection</h1>
<?php if(isset($success)): ?>
<h2>Connect� !</h2>
<?php
echo 'access_token : '.$_COOKIE['access_token'].'<br />';
echo 'access_token_secret : '.$_COOKIE['access_token_secret'];
?>
<?php elseif(isset($error)): ?>
<p>Error. <a href="index.php">Try again?</a></p>
<?php else: ?>
<form action="" method="post">
<input type="hidden" value="1" name="auth" />
<input type="image" src="img/sign-in-with-twitter-l.png"
alt="Connect to Twitter" name="auth" value="1">
</form>
<p>Connect to Twitter to use this app.</p>
<?php endif; ?>

</body>
</html>