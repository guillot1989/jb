<?php
$openinviter_settings=array(
'username'=>"Narcoflik", 'private_key'=>"d61e5fa635341dab17b73ee7e50ca03f", 'cookie_path'=>"c:/wamp/tmp", 'message_body'=>"You are invited to qlAppshop.com", 'message_subject'=>" is inviting you to qlAppshop.com", 'transport'=>"curl", 'local_debug'=>"on_error", 'remote_debug'=>"", /* modifier votre host ex : jolielist.com à la place de 127...1 */ 'hosted'=>"127.0.0.1", 'proxies'=>array(),
'stats'=>"", 'plugins_cache_time'=>"1800", 'plugins_cache_file'=>"oi_plugins.php", 'update_files'=>"1", 'stats_user'=>"", 'stats_password'=>"");
// include our libraries
include '../lib/tmhOAuth.php';
include '../lib/TwitterApp.php';

// set the consumer key and secret
define('CONSUMER_KEY',      'mUrVNLaLwmhCOCug2G5g');
define('CONSUMER_SECRET',   '9cDoBKsbJ1Lx0KRSvE6xCzN4yEfFu0woLYIuXzEQ');

// our tmhOAuth settings
$config = array(
		'consumer_key'      => CONSUMER_KEY,
		'consumer_secret'   => CONSUMER_SECRET
);

?>